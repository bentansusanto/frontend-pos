export interface Category {
  id: string;
  name_category: string;
}
