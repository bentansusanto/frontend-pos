import { PosPage } from "@/components/modules/POS/POSPage";

export default function NewOrderPage() {
  return <PosPage />;
}
