import { ProductDetails } from "@/components/modules/Products/ProductDetails";

export default function ProductDetailPage() {
  return <ProductDetails />;
}
