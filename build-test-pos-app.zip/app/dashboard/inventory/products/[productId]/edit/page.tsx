import { UpdateProduct } from "@/components/modules/Products/UpdateProduct/UpdateProduct";

export default function UpdateProductPage() {
  return <UpdateProduct />;
}
