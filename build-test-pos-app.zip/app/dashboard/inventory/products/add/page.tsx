import { AddProduct } from "@/components/modules/Products/AddProduct/AddProduct";

export default function AddProductPage() {
  return <AddProduct />;
}
