import { ProductPage } from "@/components/modules/Products/ProductPage";

export default function ProductsPage() {
  return <ProductPage />;
}
