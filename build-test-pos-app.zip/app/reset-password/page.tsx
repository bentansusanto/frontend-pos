import { ResetPasswordPage } from "@/components/modules/ResetPassword/ResetPasswordPage";

export default function ResetPassword() {
  return <ResetPasswordPage />;
}
