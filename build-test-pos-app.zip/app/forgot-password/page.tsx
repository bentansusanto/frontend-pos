import { ForgotPasswordPage } from "@/components/modules/ForgotPassword/ForgotPasswordPage";

export default function ForgotPassword() {
  return <ForgotPasswordPage />;
}
